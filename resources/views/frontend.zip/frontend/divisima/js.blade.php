
<script src="{{ Helper::backend('vendor/jquery/jquery.min.js') }}"></script>
<script src="{{ Helper::backend('vendor/jquery-ui/js/jquery-ui.min.js') }}"></script>
<script src="{{ Helper::frontend('js/bootstrap.min.js') }}"></script>
<script src="{{ Helper::frontend('js/jquery.slicknav.min.js') }}"></script>
<script src="{{ Helper::frontend('js/owl.carousel.min.js') }}"></script>
<script src="{{ Helper::frontend('js/jquery.nicescroll.min.js') }}"></script>
<script src="{{ Helper::frontend('js/jquery.zoom.min.js') }}"></script>
<script src="{{ Helper::frontend('js/notiny.min.js') }}"></script>
<script src="{{ Helper::backend('vendor/chosen/chosen.jquery.min.js') }}"></script>
<script src="{{ Helper::frontend('js/main.js') }}"></script>

@stack('javascript')

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>