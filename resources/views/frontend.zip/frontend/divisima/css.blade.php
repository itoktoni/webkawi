<!-- Stylesheets -->
<link rel="stylesheet" href="{{ Helper::frontend('css/bootstrap.min.css') }}" />
<link rel="stylesheet" href="{{ Helper::frontend('css/font-awesome.min.css') }}" />
<link rel="stylesheet" href="{{ Helper::frontend('css/flaticon.min.css') }}" />
<link rel="stylesheet" href="{{ Helper::frontend('css/slicknav.min.css') }}" />
<link rel="stylesheet" href="{{ Helper::frontend('css/jquery-ui.min.css') }}" />
<link rel="stylesheet" href="{{ Helper::frontend('css/owl.carousel.min.css') }}" />
<link rel="stylesheet" href="{{ Helper::frontend('css/animate.min.css') }}" />
<link rel="stylesheet" href="{{ Helper::frontend('css/notiny.min.css') }}" />
<link rel="stylesheet" href="{{ Helper::backend('vendor/chosen/chosen.min.css') }}">
<link rel="stylesheet" href="{{ Helper::frontend('css/style.min.css') }}" />