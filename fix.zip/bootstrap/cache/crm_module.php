<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Crm\\Providers\\ModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Crm\\Providers\\ModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);