<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Sales\\Providers\\ModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Sales\\Providers\\ModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);