<?php

return [
    'name' => 'Procurement'
];
