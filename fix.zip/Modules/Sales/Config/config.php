<?php

return [
    'name' => 'Sales'
];
