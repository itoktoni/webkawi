@component('component.livewire')
@endcomponent
@livewire('wo-detail', $model->$key)
